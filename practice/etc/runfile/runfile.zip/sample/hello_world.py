with open("hello_world.txt", "w") as f:
    f.write("hello world")